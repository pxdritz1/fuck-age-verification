"use strict";
(() => {
  // src/core/browser.ts
  var globalScope = globalThis;
  var ext = globalScope.browser ?? globalScope.chrome;
  var SETTINGS_KEY = "settings";
  async function storageGet(key) {
    if (!ext?.storage?.local) return void 0;
    const result = await ext.storage.local.get(key);
    return result[key];
  }
  async function storageSet(key, value) {
    if (!ext?.storage?.local) return;
    await ext.storage.local.set({ [key]: value });
  }
  function getVersion() {
    try {
      return ext?.runtime?.getManifest?.().version ?? "0.0.0";
    } catch {
      return "0.0.0";
    }
  }

  // src/core/host.ts
  var PATTERN = /^(\*|https?|file|ftp):\/\/(\*|\*\.[^/]+|[^/]+)(\/.*)$/;
  function globToRegExp(glob) {
    const escaped = glob.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".");
    return new RegExp(`^${escaped}$`);
  }
  function matchPattern(pattern, url) {
    const parts = PATTERN.exec(pattern);
    if (!parts) return false;
    const scheme = parts[1];
    const host = parts[2];
    const path = parts[3];
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      return false;
    }
    if (scheme === "*") {
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return false;
    } else if (scheme === "file") {
      if (parsed.protocol !== "file:") return false;
    } else if (`${scheme}:` !== parsed.protocol) {
      return false;
    }
    if (host !== "*") {
      const hostname = parsed.hostname.toLowerCase();
      const expected = host.toLowerCase();
      if (expected.startsWith("*.")) {
        const suffix = expected.slice(2);
        if (hostname !== suffix && !hostname.endsWith(`.${suffix}`)) return false;
      } else if (hostname !== expected) {
        return false;
      }
    }
    return globToRegExp(path).test(parsed.pathname + parsed.search);
  }

  // src/core/settings.ts
  var DEFAULT_SETTINGS = {
    enabled: true,
    modules: {},
    showToasts: true
  };
  function normalizeSettings(value, moduleIds2) {
    const source = value && typeof value === "object" ? value : {};
    const rawModules = source.modules && typeof source.modules === "object" ? source.modules : {};
    const modules = {};
    for (const id of moduleIds2) {
      modules[id] = rawModules[id] !== false;
    }
    return {
      enabled: source.enabled !== false,
      modules,
      showToasts: source.showToasts !== false
    };
  }

  // src/modules/bluesky/module.json
  var module_default = {
    id: "bluesky",
    name: "Bluesky",
    description: "Remove avisos de conte\xFAdo sens\xEDvel e a verifica\xE7\xE3o de idade do Bluesky.",
    matches: ["*://*.bsky.app/*"],
    order: 65,
    color: "#0085ff",
    category: "Social",
    pageScript: "page.ts",
    pageRunAt: "document_start"
  };

  // src/modules/discord/module.json
  var module_default2 = {
    id: "discord",
    name: "Discord",
    description: "Abre canais com restri\xE7\xE3o de idade no Discord Web.",
    matches: ["*://*.discord.com/*"],
    order: 90,
    color: "#5865f2",
    category: "Comunidade"
  };

  // src/modules/facebook/module.json
  var module_default3 = {
    id: "facebook",
    name: "Facebook",
    description: "Pula a confirma\xE7\xE3o de idade de p\xE1ginas e avisos de conte\xFAdo sens\xEDvel.",
    matches: ["*://*.facebook.com/*"],
    order: 50,
    color: "#1877f2",
    category: "Social"
  };

  // src/modules/instagram/module.json
  var module_default4 = {
    id: "instagram",
    name: "Instagram",
    description: "Abre posts com aviso de conte\xFAdo sens\xEDvel automaticamente.",
    matches: ["*://*.instagram.com/*"],
    order: 40,
    color: "#e1306c",
    category: "Social"
  };

  // src/modules/reddit/module.json
  var module_default5 = {
    id: "reddit",
    name: "Reddit",
    description: "Pula o aviso 18+ e mant\xE9m o cookie over18 ativo.",
    matches: ["*://*.reddit.com/*"],
    order: 10,
    color: "#ff4500",
    category: "Social",
    cookies: [
      {
        name: "over18",
        value: "1",
        domain: ".reddit.com",
        path: "/",
        secure: true,
        sameSite: "lax",
        expirationDays: 3650
      }
    ]
  };

  // src/modules/steam/module.json
  var module_default6 = {
    id: "steam",
    name: "Steam",
    description: "Define os cookies de idade e preenche o age gate da loja.",
    matches: ["*://*.steampowered.com/*", "*://*.steamcommunity.com/*"],
    order: 100,
    color: "#66c0f4",
    category: "Games",
    cookies: [
      {
        name: "wants_mature_content",
        value: "1",
        domain: ".steampowered.com",
        path: "/",
        secure: true,
        sameSite: "lax",
        expirationDays: 3650
      },
      {
        name: "lastagecheckage",
        value: "1-January-1995",
        domain: ".steampowered.com",
        path: "/",
        secure: true,
        sameSite: "lax",
        expirationDays: 3650
      },
      {
        name: "birthtime",
        value: "788914801",
        domain: ".steampowered.com",
        path: "/",
        secure: true,
        sameSite: "lax",
        expirationDays: 3650
      },
      {
        name: "wants_mature_content",
        value: "1",
        domain: ".steamcommunity.com",
        path: "/",
        secure: true,
        sameSite: "lax",
        expirationDays: 3650
      },
      {
        name: "mature_content",
        value: "1",
        domain: ".steamcommunity.com",
        path: "/",
        secure: true,
        sameSite: "lax",
        expirationDays: 3650
      }
    ]
  };

  // src/modules/threads/module.json
  var module_default7 = {
    id: "threads",
    name: "Threads",
    description: "Abre posts com aviso de conte\xFAdo sens\xEDvel automaticamente.",
    matches: ["*://*.threads.net/*", "*://*.threads.com/*"],
    order: 60,
    color: "#a1a1aa",
    category: "Social"
  };

  // src/modules/tiktok/module.json
  var module_default8 = {
    id: "tiktok",
    name: "TikTok",
    description: "Pula avisos de conte\xFAdo sens\xEDvel e confirma\xE7\xF5es de idade.",
    matches: ["*://*.tiktok.com/*"],
    order: 70,
    color: "#25f4ee",
    category: "Social"
  };

  // src/modules/twitch/module.json
  var module_default9 = {
    id: "twitch",
    name: "Twitch",
    description: "Remove o aviso de conte\xFAdo adulto e inicia a transmiss\xE3o automaticamente.",
    matches: ["*://*.twitch.tv/*"],
    order: 80,
    color: "#9146ff",
    category: "V\xEDdeo"
  };

  // src/modules/x/module.json
  var module_default10 = {
    id: "x",
    name: "X (Twitter)",
    description: "Desativa o fluxo de verifica\xE7\xE3o de idade e os avisos de conte\xFAdo sens\xEDvel.",
    matches: ["*://*.x.com/*", "*://*.twitter.com/*"],
    order: 20,
    color: "#e7e9ea",
    category: "Social",
    pageScript: "page.ts"
  };

  // src/modules/youtube/module.json
  var module_default11 = {
    id: "youtube",
    name: "YouTube",
    description: "Desbloqueia v\xEDdeos com restri\xE7\xE3o de idade e pula avisos de conte\xFAdo.",
    matches: ["*://*.youtube.com/*"],
    order: 30,
    color: "#ff0033",
    category: "V\xEDdeo",
    pageScript: "page.ts",
    pageMatches: ["*://*.youtube.com/*"],
    pageRunAt: "document_start",
    pageAllFrames: true
  };

  // src/modules/catalog.ts
  var catalog = [module_default5, module_default10, module_default11, module_default4, module_default3, module_default7, module_default, module_default8, module_default9, module_default2, module_default6].sort((left, right) => (left.order ?? 100) - (right.order ?? 100));

  // src/popup/index.ts
  var app = document.querySelector("#app");
  var moduleIds = catalog.map((module) => module.id);
  var settings = normalizeSettings(DEFAULT_SETTINGS, moduleIds);
  var currentTabId;
  var currentModuleId;
  if (app) {
    void main();
  }
  async function main() {
    const stored = await storageGet(SETTINGS_KEY);
    settings = normalizeSettings(stored, moduleIds);
    try {
      const tabs = await ext?.tabs?.query({ active: true, currentWindow: true });
      const tab = tabs?.[0];
      currentTabId = tab?.id;
      if (tab?.url) {
        currentModuleId = catalog.find(
          (module) => module.matches.some((pattern) => matchPattern(pattern, tab.url))
        )?.id;
      }
    } catch {
    }
    render();
    ext?.storage?.onChanged?.addListener((changes, area) => {
      if (area !== "local" || !changes[SETTINGS_KEY]) return;
      settings = normalizeSettings(changes[SETTINGS_KEY].newValue, moduleIds);
      render();
    });
  }
  function render() {
    if (!app) return;
    const current = catalog.find((module) => module.id === currentModuleId);
    const version = getVersion();
    app.innerHTML = `
    <header class="hero">
      <div class="brand">
        <div class="mark" aria-hidden="true">18<span>\xD7</span></div>
        <div>
          <h1>Fuck Age Verification</h1>
          <p>Gates client-side, avisos de conte\xFAdo e overlays 18+ fora do caminho.</p>
        </div>
      </div>
      <label class="switch" title="Ligar ou desligar tudo">
        <input id="global" type="checkbox" ${settings.enabled ? "checked" : ""} />
        <span class="track"><span class="thumb"></span></span>
      </label>
    </header>

    <section class="current ${current ? "is-active" : ""}">
      <span class="dot" style="--dot:${current?.color ?? "#71717a"}"></span>
      <div>
        <strong>${current ? escapeHtml(current.name) : "Nenhum site compat\xEDvel nesta aba"}</strong>
        <small>${current ? "M\xF3dulo ativo nesta aba" : "Abra um dos sites suportados para usar"}</small>
      </div>
      ${current && currentTabId !== void 0 ? '<button id="reload" class="ghost" type="button">Recarregar</button>' : ""}
    </section>

    <main class="modules">
      ${catalog.map(renderModule).join("")}
    </main>

    <footer>
      <label class="toasts" title="Mostrar notifica\xE7\xF5es da extens\xE3o">
        <input id="toasts" type="checkbox" ${settings.showToasts ? "checked" : ""} />
        notifica\xE7\xF5es
      </label>
      <span>v${escapeHtml(version)}</span>
      <a href="https://github.com/pxdritz1/fuck-age-verification" target="_blank" rel="noreferrer">GitHub</a>
    </footer>
  `;
    bind();
  }
  function renderModule(module) {
    const enabled = settings.enabled && settings.modules[module.id] !== false;
    const isCurrent = currentModuleId === module.id;
    return `
    <label class="module ${enabled ? "" : "is-off"} ${isCurrent ? "is-current" : ""}">
      <span class="badge" style="--badge:${module.color ?? "#71717a"}">${escapeHtml(module.name.slice(0, 1))}</span>
      <span class="info">
        <span class="name">
          ${escapeHtml(module.name)}
          ${isCurrent ? "<em>nesta aba</em>" : ""}
        </span>
        <span class="desc">${escapeHtml(module.description)}</span>
      </span>
      <span class="switch small">
        <input
          type="checkbox"
          data-module="${module.id}"
          ${enabled ? "checked" : ""}
          ${settings.enabled ? "" : "disabled"}
        />
        <span class="track"><span class="thumb"></span></span>
      </span>
    </label>
  `;
  }
  function bind() {
    if (!app) return;
    app.querySelector("#global")?.addEventListener("change", (event) => {
      settings.enabled = event.target.checked;
      void save();
    });
    for (const input of app.querySelectorAll("input[data-module]")) {
      input.addEventListener("change", () => {
        const id = input.dataset.module;
        if (!id) return;
        settings.modules[id] = input.checked;
        void save();
      });
    }
    app.querySelector("#toasts")?.addEventListener("change", (event) => {
      settings.showToasts = event.target.checked;
      void save();
    });
    app.querySelector("#reload")?.addEventListener("click", () => {
      if (currentTabId !== void 0) void ext?.tabs?.reload(currentTabId);
    });
  }
  async function save() {
    await storageSet(SETTINGS_KEY, settings);
    render();
  }
  function escapeHtml(value) {
    const entities = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    };
    return value.replace(/[&<>"']/g, (character) => entities[character]);
  }
})();
