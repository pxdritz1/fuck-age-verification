"use strict";
(() => {
  // src/modules/youtube/unlock.ts
  var AGE_STATUSES = /* @__PURE__ */ new Set([
    "AGE_VERIFICATION_REQUIRED",
    "AGE_CHECK_REQUIRED",
    "CONTENT_CHECK_REQUIRED",
    "LOGIN_REQUIRED"
  ]);
  var VALID_STATUSES = /* @__PURE__ */ new Set(["OK", "LIVE_STREAM_OFFLINE"]);
  var playerCache = /* @__PURE__ */ new Map();
  var signatureTimestamp;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function isPlayerResponse(value) {
    if (!isRecord(value)) return false;
    const hasDetails = isRecord(value.videoDetails);
    const hasStatus = isRecord(value.playabilityStatus);
    return hasDetails && hasStatus || isRecord(value.previewPlayabilityStatus);
  }
  function isAgeRestricted(player) {
    const status = player.previewPlayabilityStatus?.status ?? player.playabilityStatus?.status;
    if (!status) return false;
    if (AGE_STATUSES.has(status)) return true;
    return Boolean(player.playabilityStatus?.desktopLegacyAgeGateReason);
  }
  function addContentCheck(body) {
    try {
      const parsed = JSON.parse(body);
      if (isRecord(parsed) && typeof parsed.videoId === "string") {
        parsed.contentCheckOk = true;
        parsed.racyCheckOk = true;
        return JSON.stringify(parsed);
      }
    } catch {
    }
    return body;
  }
  function getYtcfgValue(name) {
    const ytcfg = window.ytcfg;
    try {
      return ytcfg?.get?.(name);
    } catch {
      return void 0;
    }
  }
  function getApiKey() {
    const value = getYtcfgValue("INNERTUBE_API_KEY");
    return typeof value === "string" && value.length > 0 ? value : void 0;
  }
  function getClientVersion() {
    const value = getYtcfgValue("INNERTUBE_CLIENT_VERSION");
    return typeof value === "string" && value.length > 0 ? value : "2.20250101.00.00";
  }
  function getClientName() {
    const value = getYtcfgValue("INNERTUBE_CONTEXT_CLIENT_NAME");
    return typeof value === "string" || typeof value === "number" ? value : void 0;
  }
  function getHl() {
    const value = getYtcfgValue("HL");
    return typeof value === "string" && value.length > 0 ? value : "en";
  }
  function isUserLoggedIn() {
    const loggedIn = getYtcfgValue("LOGGED_IN");
    if (typeof loggedIn === "boolean") return loggedIn;
    const sessionIndex = Number(getYtcfgValue("SESSION_INDEX"));
    return Number.isFinite(sessionIndex) && sessionIndex >= 0;
  }
  function getSignatureTimestamp() {
    if (signatureTimestamp !== void 0) return signatureTimestamp;
    const value = getYtcfgValue("STS");
    if (typeof value === "number") {
      signatureTimestamp = value;
      return value;
    }
    if (typeof value === "string" && /^\d+$/.test(value)) {
      signatureTimestamp = Number(value);
      return signatureTimestamp;
    }
    const script = document.querySelector('script[src*="/base.js"]');
    if (!script?.src) return void 0;
    try {
      const request = new XMLHttpRequest();
      request.open("GET", script.src, false);
      request.send(null);
      const match = request.responseText.match(/signatureTimestamp:(\d+)/);
      if (match?.[1]) {
        signatureTimestamp = Number(match[1]);
        return signatureTimestamp;
      }
    } catch {
    }
    return void 0;
  }
  function buildPayload(videoId, strategy, hl) {
    const client = {
      clientName: strategy.clientName,
      clientVersion: strategy.clientVersion,
      hl
    };
    if (strategy.clientScreen) client.clientScreen = strategy.clientScreen;
    const context = { client };
    if (strategy.thirdParty) context.thirdParty = { embedUrl: "https://www.youtube.com/" };
    const timestamp = getSignatureTimestamp();
    return {
      context,
      playbackContext: timestamp ? { contentPlaybackContext: { signatureTimestamp: timestamp } } : void 0,
      videoId,
      startTimeSecs: 0,
      racyCheckOk: true,
      contentCheckOk: true
    };
  }
  function requestPlayer(videoId) {
    const apiKey = getApiKey();
    if (!apiKey) return void 0;
    const hl = getHl();
    const clientVersion = getClientVersion();
    const clientName = getClientName();
    const strategies = [
      {
        clientName: "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
        clientVersion: "2.0",
        clientScreen: "WATCH",
        thirdParty: true
      },
      { clientName: "WEB", clientVersion },
      { clientName: "WEB_CREATOR", clientVersion: "1.20210909.07.00", requiresAuth: true }
    ];
    for (const strategy of strategies) {
      if (strategy.requiresAuth && !isUserLoggedIn()) continue;
      try {
        const request = new XMLHttpRequest();
        request.open(
          "POST",
          `/youtubei/v1/player?key=${encodeURIComponent(apiKey)}&prettyPrint=false`,
          false
        );
        request.withCredentials = Boolean(strategy.requiresAuth);
        request.setRequestHeader("Content-Type", "application/json");
        if (clientName !== void 0) {
          request.setRequestHeader("X-YouTube-Client-Name", String(clientName));
        }
        request.setRequestHeader("X-YouTube-Client-Version", clientVersion);
        request.send(JSON.stringify(buildPayload(videoId, strategy, hl)));
        if (request.status < 200 || request.status >= 300) continue;
        const result = JSON.parse(request.responseText);
        if (!isPlayerResponse(result)) continue;
        const status = result.playabilityStatus?.status;
        if (status && VALID_STATUSES.has(status)) return result;
      } catch {
      }
    }
    return void 0;
  }
  function applyUnlocked(player, unlocked) {
    if (player.previewPlayabilityStatus) {
      player.previewPlayabilityStatus = unlocked.playabilityStatus;
    }
    Object.assign(player, unlocked);
  }
  function unlockPlayerResponse(player) {
    if (!isAgeRestricted(player)) return false;
    const videoId = player.videoDetails?.videoId;
    if (!videoId) return false;
    const cached = playerCache.get(videoId);
    if (cached) {
      applyUnlocked(player, cached);
      return true;
    }
    const unlocked = requestPlayer(videoId);
    if (!unlocked) return false;
    const status = unlocked.playabilityStatus?.status;
    if (!status || !VALID_STATUSES.has(status)) return false;
    if (playerCache.size >= 20) {
      const oldest = playerCache.keys().next().value;
      if (oldest) playerCache.delete(oldest);
    }
    playerCache.set(videoId, unlocked);
    applyUnlocked(player, unlocked);
    return true;
  }
  function copyFunctionMeta(source, target) {
    for (const key of ["name", "length"]) {
      try {
        Object.defineProperty(target, key, { value: source[key], configurable: true });
      } catch {
      }
    }
  }
  function interceptProperty(property, onSet) {
    const dataKey = `__fav_${property}`;
    const descriptor = Object.getOwnPropertyDescriptor(Object.prototype, property);
    const getter = descriptor?.get ?? function() {
      return this[dataKey];
    };
    const setter = descriptor?.set ?? function(value) {
      this[dataKey] = value;
    };
    Object.defineProperty(Object.prototype, property, {
      configurable: true,
      get() {
        return getter.call(this);
      },
      set(value) {
        setter.call(this, value ? onSet(value) : value);
      }
    });
  }
  var INSTALL_KEY = "__FAV_YOUTUBE_PATCHED__";
  function install() {
    const scope = window;
    if (scope[INSTALL_KEY]) return;
    try {
      Object.defineProperty(scope, INSTALL_KEY, { value: true, configurable: false });
    } catch {
      scope[INSTALL_KEY] = true;
    }
    const enabled = () => document.documentElement?.getAttribute("data-fav-youtube") !== "0";
    const patchPlayer = (value) => {
      if (!enabled() || !isPlayerResponse(value)) return false;
      return unlockPlayerResponse(value);
    };
    try {
      let current = scope.ytInitialPlayerResponse;
      if (current) patchPlayer(current);
      Object.defineProperty(scope, "ytInitialPlayerResponse", {
        configurable: true,
        get() {
          return current;
        },
        set(value) {
          current = value;
          patchPlayer(value);
        }
      });
    } catch (error) {
      console.debug("[FAV:youtube] ytInitialPlayerResponse hook failed", error);
    }
    const nativeParse = JSON.parse;
    const parse = function(text, reviver) {
      const result = nativeParse(text, reviver);
      if (enabled() && typeof text === "string" && text.includes("playabilityStatus")) {
        patchPlayer(result);
      }
      return result;
    };
    copyFunctionMeta(nativeParse, parse);
    JSON.parse = parse;
    if (typeof Response !== "undefined" && typeof Response.prototype.json === "function") {
      const nativeJson = Response.prototype.json;
      Response.prototype.json = function() {
        return nativeJson.call(this).then((result) => {
          patchPlayer(result);
          return result;
        });
      };
    }
    interceptProperty("playerResponse", (value) => {
      if (patchPlayer(value)) {
        try {
          return JSON.parse(JSON.stringify(value));
        } catch {
          return value;
        }
      }
      return value;
    });
    if (typeof window.fetch === "function") {
      const nativeFetch = window.fetch;
      window.fetch = function(input, init) {
        try {
          const url = typeof input === "string" ? input : input instanceof Request ? input.url : input.toString();
          if (enabled() && /\/youtubei\/v1\/(player|next)/.test(url) && init?.body && typeof init.body === "string") {
            init = { ...init, body: addContentCheck(init.body) };
          }
        } catch {
        }
        return nativeFetch.call(this, input, init);
      };
    }
    const nativeOpen = XMLHttpRequest.prototype.open;
    const nativeSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      this.__favUrl = String(url);
      return nativeOpen.apply(this, [method, url, ...rest]);
    };
    XMLHttpRequest.prototype.send = function(body) {
      try {
        if (enabled() && typeof body === "string" && this.__favUrl && /\/youtubei\/v1\/(player|next)/.test(this.__favUrl)) {
          body = addContentCheck(body);
        }
      } catch {
      }
      return nativeSend.call(this, body);
    };
  }

  // src/modules/youtube/page.ts
  install();
})();
