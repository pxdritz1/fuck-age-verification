"use strict";
(() => {
  // src/modules/x/tweets.ts
  var QUOTED_KEYS = [
    "quoted_status_result",
    "quotedRefResult",
    "nested_quoted_tweet_results"
  ];
  function isDomNode(value) {
    return typeof Node !== "undefined" && value instanceof Node;
  }
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value) && !isDomNode(value);
  }
  function safeGet(object, key) {
    try {
      return object[key];
    } catch {
      return void 0;
    }
  }
  function isTweetVisibilityResult(value) {
    return isRecord(value) && value.__typename === "TweetWithVisibilityResults" && isRecord(value.tweet);
  }
  function clearProfileInterstitial(tweet) {
    const core = safeGet(tweet, "core");
    if (!isRecord(core)) return;
    const userResults = safeGet(core, "user_results");
    if (!isRecord(userResults)) return;
    const result = safeGet(userResults, "result");
    if (!isRecord(result)) return;
    const profileMetadata = safeGet(result, "profile_metadata");
    if (!isRecord(profileMetadata)) return;
    try {
      profileMetadata.profile_interstitial_type = "";
    } catch {
    }
  }
  function clearSensitiveFlag(tweet) {
    const legacy = safeGet(tweet, "legacy");
    if (!isRecord(legacy)) return;
    const current = safeGet(legacy, "possibly_sensitive");
    try {
      if (typeof current === "string") legacy.possibly_sensitive = "false";
      else if (typeof current === "number") legacy.possibly_sensitive = 0;
      else legacy.possibly_sensitive = false;
    } catch {
    }
  }
  function normalizeTweetResult(value) {
    if (!isRecord(value)) return value;
    let tweet = value;
    if (isTweetVisibilityResult(tweet)) {
      tweet = { ...tweet.tweet, __typename: "Tweet" };
      delete tweet.tweet;
    }
    clearProfileInterstitial(tweet);
    clearSensitiveFlag(tweet);
    for (const key of QUOTED_KEYS) {
      const holder = safeGet(tweet, key);
      if (!isRecord(holder)) continue;
      const result = safeGet(holder, "result");
      if (result === void 0) continue;
      try {
        holder.result = normalizeTweetResult(result);
      } catch {
      }
    }
    return tweet;
  }
  function patchTweetResults(root) {
    let changed = 0;
    const seen = /* @__PURE__ */ new WeakSet();
    const stack = [root];
    while (stack.length > 0) {
      const value = stack.pop();
      if (Array.isArray(value)) {
        if (seen.has(value)) continue;
        seen.add(value);
        for (let index = 0; index < value.length; index += 1) {
          const item = value[index];
          if (isTweetVisibilityResult(item)) {
            const normalized = normalizeTweetResult(item);
            value[index] = normalized;
            changed += 1;
            stack.push(normalized);
          } else if (item && typeof item === "object") {
            stack.push(item);
          }
        }
        continue;
      }
      if (!isRecord(value) || seen.has(value)) continue;
      seen.add(value);
      for (const key of Object.keys(value)) {
        const child = safeGet(value, key);
        if (isTweetVisibilityResult(child)) {
          const normalized = normalizeTweetResult(child);
          try {
            value[key] = normalized;
            changed += 1;
            stack.push(normalized);
          } catch {
          }
        } else if (child && typeof child === "object") {
          stack.push(child);
        }
      }
    }
    return changed;
  }

  // src/modules/x/patch-state.ts
  var X_FLAGS = {
    rweb_age_assurance_flow_enabled: false,
    age_verification_gate_enabled: false,
    sensitive_tweet_warnings_enabled: false,
    sensitive_media_settings_enabled: true,
    grok_settings_age_restriction_enabled: false,
    rweb_mvr_blurred_media_interstitial_enabled: false
  };
  var FLAG_NAMES = new Set(Object.keys(X_FLAGS));
  var RELEVANT_PATTERN = /rweb_age_assurance_flow_enabled|age_verification_gate_enabled|sensitive_tweet_warnings_enabled|sensitive_media_settings_enabled|grok_settings_age_restriction_enabled|rweb_mvr_blurred_media_interstitial_enabled|TweetWithVisibilityResults|possibly_sensitive|profile_interstitial_type|featureSwitch/;
  function isDomNode2(value) {
    return typeof Node !== "undefined" && value instanceof Node;
  }
  function isRecord2(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value) && !isDomNode2(value);
  }
  function safeGet2(object, key) {
    try {
      return object[key];
    } catch {
      return void 0;
    }
  }
  function writeTyped(object, key, desired) {
    try {
      const current = object[key];
      const next = typeof current === "string" ? String(desired) : typeof current === "number" ? desired ? 1 : 0 : desired;
      if (current === next) return false;
      object[key] = next;
      return object[key] === next;
    } catch {
      return false;
    }
  }
  function writeValue(object, key, desired) {
    const current = safeGet2(object, key);
    if (isRecord2(current) && "value" in current) {
      return writeTyped(current, "value", desired);
    }
    return writeTyped(object, key, desired);
  }
  function patchRoot(value) {
    return patchState(value) + patchTweetResults(value);
  }
  function patchState(root) {
    let changed = 0;
    const seen = /* @__PURE__ */ new WeakSet();
    const stack = [root];
    while (stack.length > 0) {
      const value = stack.pop();
      if (!value || typeof value !== "object" || isDomNode2(value)) continue;
      if (seen.has(value)) continue;
      seen.add(value);
      if (Array.isArray(value)) {
        for (const item of value) stack.push(item);
        continue;
      }
      const object = value;
      const featureSwitch = safeGet2(object, "featureSwitch");
      if (isRecord2(featureSwitch)) {
        const overrides = safeGet2(featureSwitch, "customOverrides");
        if (isRecord2(overrides)) {
          for (const [flag, desired] of Object.entries(X_FLAGS)) {
            if (Object.prototype.hasOwnProperty.call(overrides, flag) && writeValue(overrides, flag, desired)) {
              changed += 1;
            }
          }
        }
      }
      const feature = safeGet2(object, "feature");
      if (typeof feature === "string" && FLAG_NAMES.has(feature) && safeGet2(object, "enabled") !== void 0) {
        if (writeValue(object, "enabled", X_FLAGS[feature])) changed += 1;
      }
      for (const flag of FLAG_NAMES) {
        if (Object.prototype.hasOwnProperty.call(object, flag) && writeValue(object, flag, X_FLAGS[flag])) {
          changed += 1;
        }
      }
      for (const key of Object.keys(object)) {
        const child = safeGet2(object, key);
        if (child && typeof child === "object") stack.push(child);
      }
    }
    return changed;
  }
  function mightBeRelevant(root, maxDepth = 6) {
    const seen = /* @__PURE__ */ new WeakSet();
    const stack = [[root, 0]];
    while (stack.length > 0) {
      const [value, depth] = stack.pop();
      if (!value || typeof value !== "object" || isDomNode2(value) || seen.has(value) || depth > maxDepth) continue;
      seen.add(value);
      if (Array.isArray(value)) {
        for (const item of value) stack.push([item, depth + 1]);
        continue;
      }
      const object = value;
      for (const key of Object.keys(object)) {
        if (FLAG_NAMES.has(key) || key === "featureSwitch") return true;
        if (key === "__typename" && safeGet2(object, key) === "TweetWithVisibilityResults") return true;
        if (key === "possibly_sensitive" || key === "profile_interstitial_type") return true;
        if (key === "feature") {
          const feature = safeGet2(object, "feature");
          if (typeof feature === "string" && FLAG_NAMES.has(feature)) return true;
        }
        const child = safeGet2(object, key);
        if (child && typeof child === "object") stack.push([child, depth + 1]);
      }
    }
    return false;
  }
  function copyFunctionMeta(source, target) {
    for (const key of ["name", "length"]) {
      try {
        Object.defineProperty(target, key, { value: source[key], configurable: true });
      } catch {
      }
    }
  }
  var INSTALL_KEY = "__FAV_X_PATCHED__";
  function install() {
    const scope = window;
    if (scope[INSTALL_KEY]) return;
    try {
      Object.defineProperty(scope, INSTALL_KEY, { value: true, configurable: false });
    } catch {
      scope[INSTALL_KEY] = true;
    }
    const enabled = () => document.documentElement?.getAttribute("data-fav-x") !== "0";
    try {
      let current = scope.__INITIAL_STATE__;
      if (current) patchRoot(current);
      Object.defineProperty(scope, "__INITIAL_STATE__", {
        configurable: true,
        get() {
          return current;
        },
        set(value) {
          current = value;
          if (enabled()) patchRoot(value);
        }
      });
    } catch (error) {
      console.debug("[FAV:x] __INITIAL_STATE__ hook failed", error);
    }
    const nativeParse = JSON.parse;
    const parse = function(text, reviver) {
      const result = nativeParse(text, reviver);
      if (enabled() && typeof text === "string" && RELEVANT_PATTERN.test(text)) patchRoot(result);
      return result;
    };
    copyFunctionMeta(nativeParse, parse);
    JSON.parse = parse;
    if (typeof Response !== "undefined" && typeof Response.prototype.json === "function") {
      const nativeJson = Response.prototype.json;
      Response.prototype.json = function() {
        return nativeJson.call(this).then((result) => {
          if (!enabled()) return result;
          if (/\/i\/api\/graphql\//.test(this.url) || mightBeRelevant(result)) patchRoot(result);
          return result;
        });
      };
    }
    const nativeAssign = Object.assign;
    const assign = function(target, ...sources) {
      const result = nativeAssign(target, ...sources);
      if (enabled() && mightBeRelevant(result)) patchRoot(result);
      return result;
    };
    copyFunctionMeta(nativeAssign, assign);
    Object.assign = assign;
  }

  // src/modules/x/page.ts
  install();
})();
