"use strict";
(() => {
  // src/core/browser.ts
  var globalScope = globalThis;
  var ext = globalScope.browser ?? globalScope.chrome;
  var SETTINGS_KEY = "settings";
  async function storageGet(key) {
    if (!ext?.storage?.local) return void 0;
    const result = await ext.storage.local.get(key);
    return result[key];
  }
  function onStorageChanged(callback) {
    ext?.storage?.onChanged?.addListener(callback);
  }

  // src/core/dom.ts
  var CLICKABLE_SELECTOR = [
    "button",
    "a[href]",
    'input[type="button"]',
    'input[type="submit"]',
    '[role="button"]',
    '[role="link"]',
    '[role="menuitem"]',
    '[tabindex]:not([tabindex="-1"])',
    "summary"
  ].join(",");
  function normalizeText(value) {
    return value.replace(/[\u200B-\u200D\uFEFF]/g, "").replace(/\s+/g, " ").trim().toLowerCase();
  }
  function collectText(element) {
    const parts = [];
    const text = element.textContent;
    if (text) parts.push(text);
    for (const attribute of ["aria-label", "title", "value", "alt"]) {
      const value = element.getAttribute(attribute);
      if (value) parts.push(value);
    }
    if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
      if (element.value) parts.push(element.value);
    }
    return parts.join(" ");
  }
  function matchesText(element, patterns) {
    const text = normalizeText(collectText(element));
    return patterns.some((pattern) => {
      if (typeof pattern === "string") {
        const expected = normalizeText(pattern);
        return text === expected || text.includes(expected);
      }
      pattern.lastIndex = 0;
      return pattern.test(text);
    });
  }
  function isVisible(element) {
    if (!(element instanceof HTMLElement)) return false;
    if (element.hidden) return false;
    if (element.getAttribute("aria-hidden") === "true") return false;
    const view = element.ownerDocument.defaultView;
    const style = view?.getComputedStyle(element);
    if (style && (style.display === "none" || style.visibility === "hidden" || style.opacity === "0")) {
      return false;
    }
    return element.getClientRects().length > 0;
  }
  function isDisabled(element) {
    return element.matches(":disabled") || element.getAttribute("aria-disabled") === "true";
  }
  function collectSearchRoots(root) {
    const roots = [root];
    const queue = [root];
    const seen = /* @__PURE__ */ new Set();
    while (queue.length > 0) {
      const current = queue.shift();
      if (seen.has(current)) continue;
      seen.add(current);
      for (const element of current.querySelectorAll("*")) {
        const shadow = element.shadowRoot;
        if (!shadow || seen.has(shadow)) continue;
        roots.push(shadow);
        queue.push(shadow);
      }
    }
    return roots;
  }
  function querySelectorAllDeep(root, selector) {
    const results = [];
    for (const searchRoot of collectSearchRoots(root)) {
      try {
        results.push(...searchRoot.querySelectorAll(selector));
      } catch {
        return [];
      }
    }
    return results;
  }
  function collectCandidates(root, rule) {
    const candidates = /* @__PURE__ */ new Set();
    const selectors = rule.selectors ?? [CLICKABLE_SELECTOR];
    for (const searchRoot of collectSearchRoots(root)) {
      for (const selector of selectors) {
        let matches;
        try {
          matches = searchRoot.querySelectorAll(selector);
        } catch {
          continue;
        }
        for (const element of matches) {
          if (rule.text && !matchesText(element, rule.text)) continue;
          candidates.add(element);
        }
      }
    }
    return [...candidates];
  }
  function clickElement(element) {
    if (element instanceof HTMLElement) {
      element.focus?.();
      element.click();
      return;
    }
    element.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
  }
  function applyClickRules(rules, document2, clicked = /* @__PURE__ */ new WeakSet()) {
    let count = 0;
    for (const rule of rules) {
      const roots = rule.scope ? querySelectorAllDeep(document2, rule.scope) : [document2];
      if (roots.length === 0) continue;
      const limit = rule.max ?? 3;
      let clickedInRule = 0;
      for (const root of roots) {
        for (const element of collectCandidates(root, rule)) {
          if (clickedInRule >= limit) break;
          if (clicked.has(element) || isDisabled(element)) continue;
          if (!rule.includeHidden && !isVisible(element)) continue;
          clicked.add(element);
          clickElement(element);
          clickedInRule += 1;
          count += 1;
        }
        if (clickedInRule >= limit) break;
      }
    }
    return count;
  }
  function removeElements(document2, selectors) {
    let count = 0;
    for (const selector of selectors) {
      let elements;
      try {
        elements = document2.querySelectorAll(selector);
      } catch {
        continue;
      }
      for (const element of elements) {
        element.remove();
        count += 1;
      }
    }
    return count;
  }
  function injectStyle(document2, id, css) {
    if (!css) return;
    const existing = document2.getElementById(id);
    if (existing) existing.remove();
    const style = document2.createElement("style");
    style.id = id;
    style.textContent = css;
    (document2.head ?? document2.documentElement).appendChild(style);
  }
  function unlockPageScroll(document2) {
    for (const element of [document2.documentElement, document2.body]) {
      if (!element) continue;
      element.style.removeProperty("overflow");
      element.style.removeProperty("position");
      element.classList.remove(
        "modal-open",
        "no-scroll",
        "overflow-hidden",
        "scroll-lock",
        "rpl-scroll-lock"
      );
    }
  }

  // src/core/toast.ts
  var HOST_ID = "fuck-age-verification-toast";
  var hideTimer;
  function showToast(message, duration = 3200) {
    if (!document.documentElement) return;
    let host = document.getElementById(HOST_ID);
    let root;
    if (host?.shadowRoot) {
      root = host.shadowRoot;
    } else {
      host = document.createElement("div");
      host.id = HOST_ID;
      host.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647;pointer-events:none;";
      root = host.attachShadow({ mode: "open" });
      root.innerHTML = `
      <style>
        :host { all: initial; }
        .toast {
          max-width: 320px;
          padding: 12px 16px;
          border: 1px solid rgba(255, 255, 255, 0.14);
          border-radius: 12px;
          background: #16161c;
          color: #f4f4f5;
          font: 13px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif;
          box-shadow: 0 12px 40px rgba(0, 0, 0, 0.45);
          animation: in 160ms ease-out;
        }
        @keyframes in {
          from { opacity: 0; transform: translateY(6px); }
          to { opacity: 1; transform: translateY(0); }
        }
      </style>
      <div class="toast" role="status"></div>
    `;
      document.documentElement.appendChild(host);
    }
    const toast = root.querySelector(".toast");
    if (!toast) return;
    toast.textContent = message;
    host.style.display = "block";
    if (hideTimer) window.clearTimeout(hideTimer);
    hideTimer = window.setTimeout(() => {
      host.style.display = "none";
    }, duration);
  }

  // src/core/context.ts
  function createContext(meta, isEnabled, getShowToasts = () => true) {
    let clicked = /* @__PURE__ */ new WeakSet();
    const log = (...args) => {
      console.debug(`[FAV:${meta.id}]`, ...args);
    };
    const observe = (callback, options = {}) => {
      const throttleMs = options.throttleMs ?? 250;
      let scheduled = false;
      let observer;
      let timer;
      const run = () => {
        if (!isEnabled()) return;
        try {
          callback();
        } catch (error) {
          log("observer callback failed", error);
        }
      };
      const schedule = () => {
        if (scheduled) return;
        scheduled = true;
        timer = window.setTimeout(() => {
          scheduled = false;
          run();
        }, throttleMs);
      };
      const start = () => {
        if (observer) return;
        observer = new MutationObserver(schedule);
        observer.observe(document.documentElement, {
          childList: true,
          subtree: true,
          attributes: options.attributes ?? true,
          attributeFilter: ["class", "style", "hidden", "aria-hidden", "open"]
        });
        document.addEventListener("DOMContentLoaded", run, { once: true });
        window.addEventListener("load", run, { once: true });
      };
      if (document.documentElement) start();
      else document.addEventListener("DOMContentLoaded", start, { once: true });
      return () => {
        observer?.disconnect();
        observer = void 0;
        if (timer) window.clearTimeout(timer);
      };
    };
    const onNavigate = (callback) => {
      let lastUrl = location.href;
      const check = () => {
        if (location.href === lastUrl) return;
        lastUrl = location.href;
        clicked = /* @__PURE__ */ new WeakSet();
        if (!isEnabled()) return;
        try {
          callback();
        } catch (error) {
          log("navigation callback failed", error);
        }
      };
      const interval = window.setInterval(check, 500);
      window.addEventListener("popstate", check);
      window.addEventListener("hashchange", check);
      return () => {
        window.clearInterval(interval);
        window.removeEventListener("popstate", check);
        window.removeEventListener("hashchange", check);
      };
    };
    const click = (rules) => {
      if (!isEnabled()) return 0;
      try {
        return applyClickRules(rules, document, clicked);
      } catch (error) {
        log("click rules failed", error);
        return 0;
      }
    };
    const remove = (selectors) => {
      if (!isEnabled()) return 0;
      return removeElements(document, selectors);
    };
    const hide = (selectors) => {
      if (selectors.length === 0) return;
      const scope = `html[data-fav-${meta.id}="1"]`;
      const css = selectors.map((selector) => `${scope} ${selector}{display:none!important}`).join("\n");
      injectStyle(document, `fav-hide-${meta.id}`, css);
    };
    const unlockScroll = () => {
      if (!isEnabled()) return;
      unlockPageScroll(document);
    };
    const toast = (message) => {
      if (!isEnabled() || !getShowToasts()) return;
      showToast(message);
    };
    const ready = () => {
      if (document.readyState !== "loading") return Promise.resolve();
      return new Promise((resolve) => {
        document.addEventListener("DOMContentLoaded", () => resolve(), { once: true });
      });
    };
    return {
      meta,
      log,
      observe,
      onNavigate,
      click,
      remove,
      hide,
      unlockScroll,
      toast,
      ready,
      isEnabled
    };
  }

  // src/core/host.ts
  var PATTERN = /^(\*|https?|file|ftp):\/\/(\*|\*\.[^/]+|[^/]+)(\/.*)$/;
  function globToRegExp(glob) {
    const escaped = glob.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".");
    return new RegExp(`^${escaped}$`);
  }
  function matchPattern(pattern, url) {
    const parts = PATTERN.exec(pattern);
    if (!parts) return false;
    const scheme = parts[1];
    const host = parts[2];
    const path = parts[3];
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      return false;
    }
    if (scheme === "*") {
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return false;
    } else if (scheme === "file") {
      if (parsed.protocol !== "file:") return false;
    } else if (`${scheme}:` !== parsed.protocol) {
      return false;
    }
    if (host !== "*") {
      const hostname = parsed.hostname.toLowerCase();
      const expected = host.toLowerCase();
      if (expected.startsWith("*.")) {
        const suffix = expected.slice(2);
        if (hostname !== suffix && !hostname.endsWith(`.${suffix}`)) return false;
      } else if (hostname !== expected) {
        return false;
      }
    }
    return globToRegExp(path).test(parsed.pathname + parsed.search);
  }
  function findModuleForUrl(modules2, url) {
    return modules2.find((module2) => module2.meta.matches.some((pattern) => matchPattern(pattern, url)));
  }

  // src/core/settings.ts
  var DEFAULT_SETTINGS = {
    enabled: true,
    modules: {},
    showToasts: true
  };
  function normalizeSettings(value, moduleIds) {
    const source = value && typeof value === "object" ? value : {};
    const rawModules = source.modules && typeof source.modules === "object" ? source.modules : {};
    const modules2 = {};
    for (const id of moduleIds) {
      modules2[id] = rawModules[id] !== false;
    }
    return {
      enabled: source.enabled !== false,
      modules: modules2,
      showToasts: source.showToasts !== false
    };
  }
  function isModuleEnabled(settings, id) {
    return settings.enabled && settings.modules[id] !== false;
  }

  // src/modules/bluesky/module.json
  var module_default = {
    id: "bluesky",
    name: "Bluesky",
    description: "Remove avisos de conte\xFAdo sens\xEDvel e a verifica\xE7\xE3o de idade do Bluesky.",
    matches: ["*://*.bsky.app/*"],
    order: 65,
    color: "#0085ff",
    category: "Social",
    pageScript: "page.ts",
    pageRunAt: "document_start"
  };

  // src/modules/discord/module.json
  var module_default2 = {
    id: "discord",
    name: "Discord",
    description: "Abre canais com restri\xE7\xE3o de idade no Discord Web.",
    matches: ["*://*.discord.com/*"],
    order: 90,
    color: "#5865f2",
    category: "Comunidade"
  };

  // src/modules/facebook/module.json
  var module_default3 = {
    id: "facebook",
    name: "Facebook",
    description: "Pula a confirma\xE7\xE3o de idade de p\xE1ginas e avisos de conte\xFAdo sens\xEDvel.",
    matches: ["*://*.facebook.com/*"],
    order: 50,
    color: "#1877f2",
    category: "Social"
  };

  // src/modules/instagram/module.json
  var module_default4 = {
    id: "instagram",
    name: "Instagram",
    description: "Abre posts com aviso de conte\xFAdo sens\xEDvel automaticamente.",
    matches: ["*://*.instagram.com/*"],
    order: 40,
    color: "#e1306c",
    category: "Social"
  };

  // src/modules/reddit/module.json
  var module_default5 = {
    id: "reddit",
    name: "Reddit",
    description: "Pula o aviso 18+ e mant\xE9m o cookie over18 ativo.",
    matches: ["*://*.reddit.com/*"],
    order: 10,
    color: "#ff4500",
    category: "Social",
    cookies: [
      {
        name: "over18",
        value: "1",
        domain: ".reddit.com",
        path: "/",
        secure: true,
        sameSite: "lax",
        expirationDays: 3650
      }
    ]
  };

  // src/modules/steam/module.json
  var module_default6 = {
    id: "steam",
    name: "Steam",
    description: "Define os cookies de idade e preenche o age gate da loja.",
    matches: ["*://*.steampowered.com/*", "*://*.steamcommunity.com/*"],
    order: 100,
    color: "#66c0f4",
    category: "Games",
    cookies: [
      {
        name: "wants_mature_content",
        value: "1",
        domain: ".steampowered.com",
        path: "/",
        secure: true,
        sameSite: "lax",
        expirationDays: 3650
      },
      {
        name: "lastagecheckage",
        value: "1-January-1995",
        domain: ".steampowered.com",
        path: "/",
        secure: true,
        sameSite: "lax",
        expirationDays: 3650
      },
      {
        name: "birthtime",
        value: "788914801",
        domain: ".steampowered.com",
        path: "/",
        secure: true,
        sameSite: "lax",
        expirationDays: 3650
      },
      {
        name: "wants_mature_content",
        value: "1",
        domain: ".steamcommunity.com",
        path: "/",
        secure: true,
        sameSite: "lax",
        expirationDays: 3650
      },
      {
        name: "mature_content",
        value: "1",
        domain: ".steamcommunity.com",
        path: "/",
        secure: true,
        sameSite: "lax",
        expirationDays: 3650
      }
    ]
  };

  // src/modules/threads/module.json
  var module_default7 = {
    id: "threads",
    name: "Threads",
    description: "Abre posts com aviso de conte\xFAdo sens\xEDvel automaticamente.",
    matches: ["*://*.threads.net/*", "*://*.threads.com/*"],
    order: 60,
    color: "#a1a1aa",
    category: "Social"
  };

  // src/modules/tiktok/module.json
  var module_default8 = {
    id: "tiktok",
    name: "TikTok",
    description: "Pula avisos de conte\xFAdo sens\xEDvel e confirma\xE7\xF5es de idade.",
    matches: ["*://*.tiktok.com/*"],
    order: 70,
    color: "#25f4ee",
    category: "Social"
  };

  // src/modules/twitch/module.json
  var module_default9 = {
    id: "twitch",
    name: "Twitch",
    description: "Remove o aviso de conte\xFAdo adulto e inicia a transmiss\xE3o automaticamente.",
    matches: ["*://*.twitch.tv/*"],
    order: 80,
    color: "#9146ff",
    category: "V\xEDdeo"
  };

  // src/modules/x/module.json
  var module_default10 = {
    id: "x",
    name: "X (Twitter)",
    description: "Desativa o fluxo de verifica\xE7\xE3o de idade e os avisos de conte\xFAdo sens\xEDvel.",
    matches: ["*://*.x.com/*", "*://*.twitter.com/*"],
    order: 20,
    color: "#e7e9ea",
    category: "Social",
    pageScript: "page.ts"
  };

  // src/modules/youtube/module.json
  var module_default11 = {
    id: "youtube",
    name: "YouTube",
    description: "Desbloqueia v\xEDdeos com restri\xE7\xE3o de idade e pula avisos de conte\xFAdo.",
    matches: ["*://*.youtube.com/*"],
    order: 30,
    color: "#ff0033",
    category: "V\xEDdeo",
    pageScript: "page.ts",
    pageMatches: ["*://*.youtube.com/*"],
    pageRunAt: "document_start",
    pageAllFrames: true
  };

  // src/modules/catalog.ts
  var catalog = [module_default5, module_default10, module_default11, module_default4, module_default3, module_default7, module_default, module_default8, module_default9, module_default2, module_default6].sort((left, right) => (left.order ?? 100) - (right.order ?? 100));

  // src/modules/bluesky/index.ts
  function setup(ctx) {
    const run = () => {
      const clicked = ctx.click([
        {
          scope: '[role="dialog"], [aria-modal="true"], article, [data-testid*="warning"], [data-testid*="label"]',
          text: [/^show$/i, /^view$/i, /^show post$/i, /^continue$/i, /^i understand$/i]
        }
      ]);
      if (clicked) ctx.unlockScroll();
    };
    ctx.onNavigate(run);
    ctx.observe(run);
    void ctx.ready().then(run);
  }

  // src/modules/discord/index.ts
  function setup2(ctx) {
    const run = () => {
      const clicked = ctx.click([
        {
          scope: '[role="dialog"], [aria-modal="true"], [class*="ageRestricted"], [class*="ageGate"]',
          text: [
            /^i understand$/i,
            /^continue$/i,
            /^view channel$/i,
            /^yes,? i'?m 18/i,
            /^enter channel$/i
          ]
        },
        {
          selectors: ['[class*="ageRestricted"] button', '[class*="ageGate"] button'],
          text: [/^i understand$/i, /^continue$/i, /^view channel$/i]
        }
      ]);
      if (clicked) ctx.unlockScroll();
    };
    ctx.onNavigate(run);
    ctx.observe(run);
    void ctx.ready().then(run);
  }

  // src/modules/facebook/index.ts
  function setup3(ctx) {
    const run = () => {
      const clicked = ctx.click([
        {
          scope: 'div[role="dialog"], [aria-modal="true"], [data-testid="age-gate"]',
          text: [
            /^i'?m over 18$/i,
            /^i am over 18$/i,
            /^yes,? i'?m 18/i,
            /^enter$/i,
            /^continue$/i,
            /^see post$/i,
            /^view post$/i,
            /^i understand$/i
          ]
        },
        {
          selectors: ['[data-testid="age-gate"] button', '[data-testid="age-gate"] [role="button"]']
        }
      ]);
      if (clicked) ctx.unlockScroll();
    };
    ctx.onNavigate(run);
    ctx.observe(run);
    void ctx.ready().then(run);
  }

  // src/modules/instagram/index.ts
  function setup4(ctx) {
    const run = () => {
      const clicked = ctx.click([
        {
          scope: 'div[role="dialog"], [aria-modal="true"], article',
          text: [
            /^view (post|photo|reel|story)$/i,
            /^see (post|photo|reel)$/i,
            /^continue$/i,
            /^i understand$/i,
            /^show$/i
          ]
        },
        {
          selectors: ['div[role="dialog"] button', '[aria-modal="true"] button'],
          text: [/^view$/i, /^continue$/i]
        }
      ]);
      if (clicked) ctx.unlockScroll();
    };
    ctx.onNavigate(run);
    ctx.observe(run);
    void ctx.ready().then(run);
  }

  // src/modules/reddit/index.ts
  var HIDE_SELECTORS = [
    "#configured-xpromo-blocking_xpromo_nsfw_blocking_desktop",
    "configured-xpromo-blocking_xpromo_nsfw_blocking",
    "desktop-dynamic-upsell-dialog",
    "xpromo-nsfw-blocking-container"
  ];
  function setup5(ctx) {
    if (ctx.isEnabled()) {
      try {
        document.cookie = "over18=1; path=/; domain=.reddit.com; secure; SameSite=Lax";
      } catch {
      }
    }
    ctx.hide(HIDE_SELECTORS);
    const run = () => {
      if (!ctx.isEnabled()) return;
      removeNsfwPrompt();
      unblurMedia();
      if (location.pathname.startsWith("/over18")) {
        const form = document.querySelector('form[action*="over18"]');
        if (form) {
          const yes = form.querySelector('input[name="over18"][value="yes"]');
          if (yes) yes.checked = true;
          form.submit();
          return;
        }
      }
      const clicked = ctx.click([
        {
          selectors: [
            'button[name="over18"]',
            'input[name="over18"][value="yes"]',
            'button[data-testid="age-gate-continue"]',
            'shreddit-age-gate button[type="submit"]'
          ]
        },
        {
          scope: 'shreddit-age-gate, [data-testid="age-gate"], [aria-modal="true"], div[role="dialog"]',
          text: [
            /^yes,? (i'?m )?(over )?18\+?$/i,
            /^i'?m over 18$/i,
            /^yes,? continue$/i,
            /^continue$/i,
            /^view community$/i,
            /^enter$/i
          ]
        }
      ]);
      if (clicked || document.body?.classList.contains("rpl-scroll-lock")) {
        ctx.unlockScroll();
      }
    };
    ctx.onNavigate(run);
    ctx.observe(run);
    void ctx.ready().then(run);
  }
  function removeNsfwPrompt() {
    const container = document.querySelector("xpromo-nsfw-blocking-container");
    container?.shadowRoot?.querySelector(".prompt")?.remove();
  }
  function unblurMedia() {
    for (const container of document.querySelectorAll("shreddit-blurred-container[blurred]")) {
      container.removeAttribute("blurred");
    }
    for (const post of document.querySelectorAll("pdp-right-rail reddit-pdp-right-rail-post")) {
      const thumbnail = post.querySelector("div[data-testid='post-thumbnail']");
      thumbnail?.querySelector("img")?.removeAttribute("style");
      thumbnail?.querySelector("div")?.remove();
    }
  }

  // src/modules/steam/index.ts
  var COOKIES = [
    ["wants_mature_content", "1"],
    ["lastagecheckage", "1-January-1995"],
    ["birthtime", "788914801"]
  ];
  function setup6(ctx) {
    if (ctx.isEnabled()) writeCookies();
    const run = () => {
      if (!ctx.isEnabled()) return;
      writeCookies();
      const day = document.querySelector(
        '#ageDay, select[name="ageDay"], select[name="age_day"]'
      );
      const month = document.querySelector(
        '#ageMonth, select[name="ageMonth"], select[name="age_month"]'
      );
      const year = document.querySelector(
        '#ageYear, select[name="ageYear"], select[name="age_year"]'
      );
      if (day && month && year) {
        setSelect(day, ["1"]);
        setSelect(month, ["1", "January", "january"]);
        setSelect(year, ["1995"]);
        const submit = document.querySelector(
          '#age_gate_btn, #age_gate_form button[type="submit"], #age_gate_form input[type="submit"], button[type="submit"], input[type="submit"]'
        );
        if (submit) {
          submit.click();
        } else {
          day.closest("form")?.submit();
        }
        return;
      }
      const clicked = ctx.click([
        { selectors: ["#age_gate_btn", 'a[href*="agecheck"]', "button[data-age-gate]"] },
        {
          scope: '#app_agegate, [id*="agegate"], [class*="agegate"], [role="dialog"], [aria-modal="true"]',
          text: [
            /^view page$/i,
            /^continue$/i,
            /^i'?m 18 or older$/i,
            /^enter$/i,
            /^yes,? i'?m 18/i
          ]
        }
      ]);
      if (clicked) ctx.unlockScroll();
    };
    ctx.onNavigate(run);
    ctx.observe(run);
    void ctx.ready().then(run);
  }
  function writeCookies() {
    for (const domain of [".steampowered.com", ".steamcommunity.com"]) {
      for (const [name, value] of COOKIES) {
        try {
          document.cookie = `${name}=${value}; path=/; domain=${domain}; secure; SameSite=Lax`;
        } catch {
        }
      }
    }
  }
  function setSelect(select, candidates) {
    for (const candidate of candidates) {
      const exists = [...select.options].some((option) => option.value === candidate);
      if (!exists) continue;
      select.value = candidate;
      select.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }
    return false;
  }

  // src/modules/threads/index.ts
  function setup7(ctx) {
    const run = () => {
      const clicked = ctx.click([
        {
          scope: 'div[role="dialog"], [aria-modal="true"], article',
          text: [
            /^view (post|thread)$/i,
            /^see post$/i,
            /^continue$/i,
            /^i understand$/i,
            /^show$/i
          ]
        },
        {
          selectors: ['div[role="dialog"] button', '[aria-modal="true"] button'],
          text: [/^view$/i, /^continue$/i]
        }
      ]);
      if (clicked) ctx.unlockScroll();
    };
    ctx.onNavigate(run);
    ctx.observe(run);
    void ctx.ready().then(run);
  }

  // src/modules/tiktok/index.ts
  function setup8(ctx) {
    const run = () => {
      const clicked = ctx.click([
        {
          scope: 'div[role="dialog"], [aria-modal="true"], [data-e2e*="age"], [data-e2e*="warning"]',
          text: [
            /^view$/i,
            /^continue$/i,
            /^watch anyway$/i,
            /^i understand$/i,
            /^show$/i,
            /^see post$/i,
            /^i'?m 18/i
          ]
        },
        {
          selectors: ['div[role="dialog"] button', '[aria-modal="true"] button'],
          text: [/^view$/i, /^continue$/i]
        }
      ]);
      if (clicked) ctx.unlockScroll();
    };
    ctx.onNavigate(run);
    ctx.observe(run);
    void ctx.ready().then(run);
  }

  // src/modules/twitch/index.ts
  function setup9(ctx) {
    const run = () => {
      const clicked = ctx.click([
        {
          selectors: [
            '[data-a-target="player-overlay-mature-accept"]',
            'button[data-a-target="player-overlay-mature-accept"]'
          ]
        },
        {
          scope: '[role="dialog"], [aria-modal="true"]',
          text: [/^start watching$/i, /^continue$/i, /^i understand$/i, /^yes,? i'?m 18/i]
        }
      ]);
      if (clicked) ctx.unlockScroll();
    };
    ctx.onNavigate(run);
    ctx.observe(run);
    void ctx.ready().then(run);
  }

  // src/modules/x/index.ts
  function setup10(ctx) {
    const run = () => {
      const clicked = ctx.click([
        {
          scope: '[data-testid="sensitiveWarning"], [aria-modal="true"], div[role="dialog"]',
          text: [/^view( profile| post)?$/i, /^show$/i, /^see post$/i, /^continue$/i, /^yes,? view$/i]
        },
        {
          selectors: [
            '[data-testid="sensitiveWarning"] [role="button"]',
            '[data-testid="sensitiveWarning"] button'
          ]
        }
      ]);
      if (clicked) ctx.unlockScroll();
    };
    ctx.onNavigate(run);
    ctx.observe(run);
    void ctx.ready().then(run);
  }

  // src/modules/youtube/index.ts
  function setup11(ctx) {
    let notified = false;
    const run = () => {
      ctx.click([
        {
          scope: 'ytd-player, tp-yt-paper-dialog, [role="dialog"]',
          text: [/^i understand$/i, /^continue$/i, /^watch anyway$/i]
        }
      ]);
      if (notified) return;
      const player = document.querySelector("ytd-player");
      const text = player?.textContent ?? "";
      if (/sign in to confirm your age|age-restricted/i.test(text)) {
        notified = true;
        ctx.toast("Tentando liberar este v\xEDdeo com restri\xE7\xE3o de idade\u2026");
      }
    };
    ctx.onNavigate(run);
    ctx.observe(run, { throttleMs: 400 });
    void ctx.ready().then(run);
  }

  // src/modules/registry.ts
  var setups = {
    reddit: setup5,
    x: setup10,
    youtube: setup11,
    instagram: setup4,
    facebook: setup3,
    threads: setup7,
    bluesky: setup,
    tiktok: setup8,
    twitch: setup9,
    discord: setup2,
    steam: setup6
  };
  var modules = catalog.map((meta) => {
    const setup12 = setups[meta.id];
    if (!setup12) throw new Error(`Missing setup for module "${meta.id}"`);
    return { meta, setup: setup12 };
  });

  // src/content/index.ts
  var module = findModuleForUrl(modules, location.href);
  if (module) {
    const activeModule = module;
    const id = activeModule.meta.id;
    const moduleIds = modules.map((definition) => definition.meta.id);
    const cacheKey = `fav:enabled:${id}`;
    let settings = DEFAULT_SETTINGS;
    let enabled = readCache(cacheKey) ?? true;
    applyFlag(id, enabled);
    void init();
    async function init() {
      const stored = await storageGet(SETTINGS_KEY);
      settings = normalizeSettings(stored, moduleIds);
      enabled = isModuleEnabled(settings, id);
      applyFlag(id, enabled);
      writeCache(cacheKey, enabled);
      onStorageChanged((changes) => {
        const change = changes[SETTINGS_KEY];
        if (!change) return;
        settings = normalizeSettings(change.newValue, moduleIds);
        enabled = isModuleEnabled(settings, id);
        applyFlag(id, enabled);
        writeCache(cacheKey, enabled);
      });
      const context = createContext(
        activeModule.meta,
        () => enabled,
        () => settings.showToasts
      );
      try {
        await activeModule.setup(context);
      } catch (error) {
        console.error(`[FAV:${id}] setup failed`, error);
      }
    }
  }
  function applyFlag(id, enabled) {
    const apply = () => {
      document.documentElement?.setAttribute(`data-fav-${id}`, enabled ? "1" : "0");
    };
    apply();
    if (!document.documentElement) {
      document.addEventListener("DOMContentLoaded", apply, { once: true });
    }
  }
  function readCache(key) {
    try {
      const value = localStorage.getItem(key);
      return value === null ? void 0 : value === "1";
    } catch {
      return void 0;
    }
  }
  function writeCache(key, enabled) {
    try {
      localStorage.setItem(key, enabled ? "1" : "0");
    } catch {
    }
  }
})();
